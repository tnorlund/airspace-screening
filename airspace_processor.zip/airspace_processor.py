import pandas as pd
import json
import numpy as np
import pytz
from haversine import haversine, Unit
import warnings
import awswrangler as wr


def to_miles( number, measure ):
  if measure == 'km':
    return number * 0.621371
  if measure == 'm':
    return number * 0.000621371192
  if measure == 'ft':
    return number * 5280
  else:
    return measure
    
def get_order_type( route_type ):
  if ( len(route_type) == 1 and route_type[0] == 'DrivingSegment' ):
    return 'drive'
  if ( route_type.count('FlyingSegment') == route_type.count('DrivingSegment') ):
    return 'hfpu'
  else:
    return 'nfo'
    
def clean_timezone( timezone ):
  if ( timezone == '"Pacific Time (US & Canada)"'):
    return 'America/Los_Angeles'
  if ( timezone == '"America/Indiana/Indianapolis"' ):
    return 'America/Chicago'
  else:
    return timezone


out = {}
out['order_id'] = []
out['company_id'] = []
out['origin_city'] = []
out['destination_city'] = []
out['pick_up_time_local'] = []
out['delivery_time_local'] = []
out['minutes_to_pickup'] = []
out['order_type'] = []
out['total_drive_distance'] = []
out['total_distance'] = []

for order_id, temp in df.groupby('order_id'):
    # Get the distance driven
    if searches.loc[ order_id ].shape[0] == 2:
        number, measure = json.loads( searches.loc[ order_id ]['json_obj'].iloc[0] )['routes'][0]['legs'][0]['distance']['text'].split(' ')
        if measure != 'mi':
            miles = to_miles( float( number.replace(',', '') ), measure )
        else:
            miles = float( number.replace(',', '') )
    elif len(
        json.loads( searches.loc[ order_id ]['json_obj'] )['routes']
    ) > 0:
        number, measure = json.loads( searches.loc[ order_id ]['json_obj'] )['routes'][0]['legs'][0]['distance']['text'].split(' ')
        if measure != 'mi':
            miles = to_miles( float( number.replace(',', '') ), measure )
        else:
            miles = float( number.replace(',', '') )
    else:
        miles = np.nan
    # Get the order type
    order_type = get_order_type( temp['route_type'].tolist() ) 
    # Get the difference between order creation and order pickup
    time_dif = abs(
        (temp['pick_up_time_local'].iloc[0] - temp['order_created_at'].iloc[0]).total_seconds() / 60
    )
    # Get the origin and destination city
    origin_city = temp['origin_city'].iloc[0]
    destination_city = temp['destination_city'].iloc[-1]
    total_distance = haversine(
            (temp['start_lat'].iloc[0], temp['start_lng'].iloc[0]),
            (temp['end_lat'].iloc[0], temp['end_lng'].iloc[0]),
            unit=Unit.MILES
        )
    # Set the times
    if ( pd.isnull( temp['pick_up_time_local'].iloc[0] ) ):
        pick_up_time_local = np.datetime64('NaT')
    else:
        pick_up_time_local = temp['pick_up_time_local'].iloc[0].astimezone( 
            clean_timezone( temp['start_time_zone'].iloc[0] )
        )
    if ( pd.isnull( temp['order_quoted_delivery_time'].iloc[0] ) ):
        delivery_time_local = np.datetime64('NaT')
    else:
        delivery_time_local = temp['order_quoted_delivery_time'].iloc[0].astimezone( 
            clean_timezone( temp['end_time_zone'].iloc[0] )
        )
    out['order_id'].append( order_id )
    out['company_id'].append( temp['order_company_id'].iloc[0] )
    out['origin_city'].append( origin_city )
    out['destination_city'].append( destination_city )
    out['pick_up_time_local'].append( pick_up_time_local )
    out['delivery_time_local'].append( delivery_time_local )
    out['minutes_to_pickup'].append( time_dif )
    out['order_type'].append( order_type )
    out['total_drive_distance'].append( miles )
    out['total_distance'].append( total_distance )
pd.DataFrame(out)

